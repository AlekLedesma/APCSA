
/**
 * Write a description of class chart here.
 *
 * @author (Alek Ledesma)
 * @version (10.9.19)
 */

//A) findKeyword("She's my sister", "sister", 0);
//B) findKeyword("Brother Tom is helpful", "brother", 0);
//C) findKeyword("I can't catch wild cats.", "cat", 0);
//D) findKeyword("I know nothing about snow plows.", "no", 0);

/*  Iteration       psn     Before      After
 *      1A           9       " "         ""     
 *      1B           1       ""          " "
 *      1C           9       " "         "c"
 *      2C           20      " "         "s"
 *      1D           4       "k"         "w"
 *      2D           8       " "         "t"   
 *      3D           23      "s"         "w"       
 */