
/**
 * Questions for PixLab.
 *
 * @author (Alek Ledesma)
 * @version (3.10.20)
 */
public class Questions
{

    /**Activity 1
     * 1    8 bits
     * 
     * 2    307200 pixels
     * 
     * 3    3 bytes
     * 
    /**Activity 2
     * 1    255 red, 204 green, 204 blue, 255 Alpha     Pink
     * 
     * 2    255 red, 255 green, 0 blue , 255 Alpha      Yellow
     * 
     * 3    204 red, 0 green, 255 blue, 255 Alpha       Purple
     * 
     * 4    255 red, 255 green, 255 blue, Alpha 255     White
     * 
     * 5    102 red, 102 green, 102 blue, 255 Alpha     Dark Grey
     * 
    /**Activity 3
     * 1    0 row
     * 
     * 2    0 column
     * 
     * 3    640 columns
     * 
     * 4    480 rows
     * 
     * 5    top to bottom
     * 
     * 6    left to right
     * 
     * 7    pixelation
     * 
     */
  
    


    
}
